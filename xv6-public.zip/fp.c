#include "types.h"
#include "stat.h"
#include "user.h"

int
main(void)
{
printf(1,"WOW it really works\n");
printf(1,"It is always fun to work with xv6\n");
exit();
}
